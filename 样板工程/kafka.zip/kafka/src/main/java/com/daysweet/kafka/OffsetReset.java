/**
 *  * @(#)OffsetReset.java, 2019年12月05日.
 *  *
 *  * Copyright 2019 Netease, Inc. All rights reserved.
 *  * NETEASE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  
 */

package com.daysweet.kafka;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;

/**
 * 重置偏移量，必须先关掉同一个group的所有消费者。
 */
public class OffsetReset {
    public static void main(String[] args) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "group-DemoConsumer");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
        props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "30000");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.IntegerDeserializer");
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");

        KafkaConsumer<Integer, String> consumer = new KafkaConsumer<>(props);
        TopicPartition partition0 = new TopicPartition(KafkaProperties.TOPIC, 0);
        Map<TopicPartition, OffsetAndMetadata> offsets = new HashMap<>();
        OffsetAndMetadata metadata = new OffsetAndMetadata(100);
        offsets.put(partition0,metadata);
        consumer.commitSync(offsets);
        consumer.close();

    }
}
