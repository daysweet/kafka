/**
 *  * @(#)HandleRebalance.java, 2019年12月05日.
 *  *
 *  * Copyright 2019 Netease, Inc. All rights reserved.
 *  * NETEASE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  
 */

package com.daysweet.kafka;

import java.util.Collection;

import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;

/**
 *  *
 *  *
 *  
 */
public class HandleRebalance implements ConsumerRebalanceListener {
    private final KafkaConsumer<Integer, String> consumer;

    public HandleRebalance(KafkaConsumer<Integer, String> consumer) {
        this.consumer = consumer;
    }

    @Override
    public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
        System.out.println("Lost partions in rebalance. Committing current offsets:");
        consumer.commitSync();

    }

    @Override
    public void onPartitionsAssigned(Collection<TopicPartition> partitions) {

    }
}
